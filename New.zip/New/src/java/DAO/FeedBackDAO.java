package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.FeedBack;

public class FeedBackDAO extends DBContext {

    public void insertFeedBack(FeedBack feedback) throws SQLException {
        String sql = "INSERT INTO FeedBack (AccountID, Content, Image, Status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, feedback.getAccountID());
            statement.setString(2, feedback.getContent());
            if (feedback.getImage() != null) {
                statement.setString(3, feedback.getImage());
            } else {
                statement.setNull(3, java.sql.Types.VARCHAR);
            }
            statement.setBoolean(4, feedback.isStatus());
            statement.executeUpdate();
        } catch (Exception e) {
            throw new SQLException("Error inserting feedback", e);
        }
    }

    public List<Map<String, Object>> selectAllFeedBacks() {
        List<Map<String, Object>> feedbacks = new ArrayList<>();
        String sql = "SELECT f.*, a.username FROM FeedBack f JOIN Account a ON f.AccountID = a.ID";
        
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                int accountId = rs.getInt("AccountID");
                String content = rs.getString("Content");
                String image = rs.getString("Image");
                Timestamp createdAt = rs.getTimestamp("CreatedAt");
                boolean status = rs.getBoolean("Status");
                String username = rs.getString("username");

                FeedBack feedback = new FeedBack(id, accountId, content, image, createdAt, status);
                Map<String, Object> feedbackWithDetails = new HashMap<>();
                feedbackWithDetails.put("feedback", feedback);
                feedbackWithDetails.put("username", username);

                feedbacks.add(feedbackWithDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbacks;
    }
}
