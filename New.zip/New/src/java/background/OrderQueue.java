/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package background;

import java.util.LinkedList;
import java.util.Queue;


/**
 *
 * @author Admin
 */
public class OrderQueue {
    public static Queue<Integer> queue = new LinkedList<>();
}
