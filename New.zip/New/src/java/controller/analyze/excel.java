
import DAO.ProductDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.util.List;

@WebServlet(name = "excel", urlPatterns = {"/excel"})
public class excel extends HttpServlet {

    private ProductDao productDao; // Declare a reference to ProductDao

    @Override
    public void init() throws ServletException {
        super.init();
        productDao = new ProductDao(); // Initialize ProductDao in init method
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=recent_products.xlsx");

        Connection connection = null; // Initialize database connection
        try {
            // Get database connection (you should implement your own method for this)
            connection = getConnection();

            // Retrieve recent products using DAO method
            List<Object[]> recentProducts = productDao.getRecentProducts( 100); 
            try (Workbook workbook = new XSSFWorkbook(); OutputStream out = response.getOutputStream()) {
                Sheet sheet = workbook.createSheet("Recent Products");

                // Create header row
                Row headerRow = sheet.createRow(0);
                String[] headers = {"Order ID", "Buyer Name", "Product Name", "Price", "Quantity", "Total", "Image"};
                for (int i = 0; i < headers.length; i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(headers[i]);
                }

                // Fill data rows
                int rowNum = 1;
                for (Object[] product : recentProducts) {
                    Row row = sheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(String.valueOf(product[0])); // Order ID
                    row.createCell(1).setCellValue(String.valueOf(product[1])); // Buyer Name
                    row.createCell(2).setCellValue(String.valueOf(product[2])); // Product Name
                    row.createCell(3).setCellValue(String.valueOf(product[3])); // Price
                    row.createCell(4).setCellValue(String.valueOf(product[4])); // Quantity
                    row.createCell(5).setCellValue(String.valueOf(product[5])); // Total
                    row.createCell(6).setCellValue(String.valueOf(product[6])); // Image URL (if needed)
                }

                // Write workbook to response output stream
                workbook.write(out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close database connection
            closeConnection(connection);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet to generate and download Excel file for recent products";
    }

    // Replace with your actual method to get database connection
    private Connection getConnection() {
        // Implement your logic to get a database connection
        return null; // Replace with your implementation
    }

    // Replace with your actual method to close database connection
    private void closeConnection(Connection connection) {
        // Implement if needed
    }
}
