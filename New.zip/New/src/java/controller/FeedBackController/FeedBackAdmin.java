package controller.FeedBackController;

import DAO.FeedBackDAO;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class FeedBackAdmin extends HttpServlet {

    private FeedBackDAO feedBackDAO;

    public void init() {
        feedBackDAO = new FeedBackDAO();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        List<Map<String, Object>> incidentReports = feedBackDAO.selectAllFeedBacks();

        // Đặt danh sách báo cáo sự cố vào request
        request.setAttribute("incidentReports", incidentReports);

        // Chuyển tiếp yêu cầu tới adminfeedback.jsp
        request.getRequestDispatcher("adminfeedback.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet FeedBackAdmin provides incident report data";
    }
}
